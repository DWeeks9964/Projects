package com.example.basicadventuregame;
//imports
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Random;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
//varibles
public int gold = 0;
public int health = 10;
public int keys = 0;

    ArrayList<String> inventory = new ArrayList<String>();
int images[]={R.drawable.room1,R.drawable.room2,R.drawable.room3, R.drawable.room4};
public int roomstate = 0;
    Random random = new Random();

    int randomNumber = random.nextInt(8 - 6) + 6;
    int i1=randomNumber;

    boolean flag;
    boolean keyfirst;
    boolean keysecond;
    boolean keythird;
    boolean keyfourth;
    boolean found;


ImageView iv;





//creating buttons and listeners
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageButton button1 = findViewById(R.id.up);
        ImageButton button2 = findViewById(R.id.down);
        ImageButton button3 = findViewById(R.id.left);
        ImageButton button4 = findViewById(R.id.right);
        Button button5 = findViewById(R.id.examine);
        Button cmd1 = findViewById(R.id.command1);
        Button cmd2 = findViewById(R.id.command2);
        Button cmd3 = findViewById(R.id.command3);
        Button cmd4 = findViewById(R.id.command4);
        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        button4.setOnClickListener(this);
        button5.setOnClickListener(this);
        cmd1.setOnClickListener(this);
        cmd2.setOnClickListener(this);
        cmd3.setOnClickListener(this);
        cmd4.setOnClickListener(this);







  iv=(ImageView) findViewById(R.id.baseImage);


        flag = true;
        keyfirst = false;
        keysecond = false;
        keythird = false;
        keyfourth = false;
        found = false;
        inventory.add("hat");

        //b1.setOnClickListener(new View.OnClickListener() {
          //  @Override
            //public void onClick(View v) {
              //  iv.setImageResource(images[roomstate]);}
                //public void upclick(View view){
                  //  roomstate = 1;
                //}








    }

//switch statements. Most of the rooms are here
    @Override

    public void onClick(View v) {
        TextView info = (TextView)findViewById(R.id.areaInfo);

        TextView healthNum = (TextView) findViewById(R.id.health);
        healthNum.setText("Health = " + health);

        TextView goldNum = (TextView) findViewById(R.id.goldView);
        goldNum.setText("Gold = " + gold);

        TextView keyNum = (TextView) findViewById(R.id.keyView);
        keyNum.setText("Keys = " + keys);
        String searchedInv = "rope";
        switch (v.getId()) {
            case R.id.command1:
                if ((roomstate == 1) && (keys == 3)) {
                    info.setText("You win!!");
                    iv.setImageResource(images[roomstate]);}
                else if (roomstate == 1) {
                    info.setText("You do not have enough keys.");
                    iv.setImageResource(images[roomstate]);
                }


                else if (roomstate == 0) {
                    gold = gold+10;
                    goldNum.setText("Gold= " + gold);
                    iv.setImageResource(images[roomstate]);
                }
                else if (roomstate == 2) {
                    health = health-i1;
                    iv.setImageResource(images[roomstate]);
                    if (health > 0) {
                        info.setText("You've been bitten!");
                    }
                    if (health <= 0) {
                        info.setText("You've died");
                    }
                }
                else if (roomstate == 3 && !keyfirst){
                    info.setText("You search the coffin and find a gem!");
                    keys = keys+1;
                    iv.setImageResource(images[roomstate]);
                    keyfirst = true;
                }
                else if (roomstate == 3 && keyfirst){
                    info.setText("You already had a gem");
                    iv.setImageResource(images[roomstate]);
                }
                break;
            case R.id.command2:
                for (String rope : inventory) {
                    if (rope.equals(searchedInv)){
                        found = true;}
                if (roomstate == 0 && found == true  && !keythird){
                    info.setText("Something bites the rope. You pull up a fish with a gem tied to it..");
                    keys = keys+1;
                    keyNum.setText("Keys = " + keys);
                    keythird = true;
                    iv.setImageResource(images[roomstate]);
                }
                else if (roomstate == 0 && keythird && found == true) {

                    info.setText("The hole is empty");
                    iv.setImageResource(images[roomstate]);
                }
                else if (roomstate == 0 && !keythird && found == false) {
                    info.setText("There is a key you cannot reach");
                    iv.setImageResource(images[roomstate]);

                }
                else if (roomstate == 2 && !keyfourth) {

                    info.setText("You find a key!");
                    keys = keys + 1;
                    keyNum.setText("Keys = " + keys);
                    keyfourth = true;
                    iv.setImageResource(images[roomstate]);
                }
                else if (roomstate == 2 && keyfourth) {

                    info.setText("You find nothing");
                    iv.setImageResource(images[roomstate]);
                }

//commands for 3

                }
            break;
            case R.id.command3:
                if (roomstate == 1) {
                    inventory.add("rope");
                    info.setText("You retrieve a rope hanging from the ceiling");
                }
                else if (roomstate == 2) {
                    gold = gold+1;
                    goldNum.setText("Gold = " + gold);
                    iv.setImageResource(images[roomstate]);
            }




                break;
            case R.id.command4:
                if (roomstate == 2 && gold < 10 && !keysecond)   {
                info.setText("Not enough gold stranga. I need 10 gold pieces for my wares.");
                    iv.setImageResource(images[roomstate]);

                }
            else if (roomstate == 2 && gold >= 10 && !keysecond) {
                gold = gold-10;
                    goldNum.setText("Gold = " + gold);
                keys = keys+1;
                    info.setText("Thank you very much. Heres a jewel.");
                    keyNum.setText("Keys = " + keys);
                    keysecond = true;
                info.setText("Thanks you kindly");
                iv.setImageResource(images[roomstate]);

            }
            else if (roomstate == 2 && gold >= 10 && keysecond) {
                    info.setText("No more stock stranger");
                }

                break;

            case R.id.up:

                if (roomstate == 0 ){
                roomstate = 1;}
                info.setText("You see an alter with slots for three gems. There are rooms to your left and right. Examine the pedastal with 1. Search for supplies with 3.");
                iv.setImageResource(images[roomstate]);


                break;
            case R.id.down:
                if (roomstate == 1 ){
                roomstate = 0;
            info.setText("The room you started in. Check pouch with 1. Check hole with 2.");}
                iv.setImageResource(images[roomstate]);

            break;
            case R.id.left:
                if (roomstate ==1){
                    roomstate =3;
                info.setText("You find a coffin in an empty room. Search with 1.");
                    iv.setImageResource(images[roomstate]);}
                else if (roomstate ==2){
                    roomstate =1;
                info.setText("You see an alter with slots for three gems. There are rooms to your left and right. Examine the pedastal with 1. Search for supplies with 3.");
                    iv.setImageResource(images[roomstate]);}

                break;
            case R.id.right:
                if (roomstate ==1){
                    roomstate =2;
                    info.setText("You find a shady merchant and three holes in the area. Chat with the man by pressing 4.");
                    iv.setImageResource(images[roomstate]);
                }
                else if (roomstate==3){
                        roomstate =1;
                    info.setText("You see an alter with slots for three gems. There are rooms to your left and right. Examine the pedastal with 1. Search for supplies with 3.");
                    iv.setImageResource(images[roomstate]);
            }
                Toast.makeText(this, "You moved right.", Toast.LENGTH_SHORT).show();
                iv.setImageResource(images[roomstate]);
                break;
            case R.id.examine:
                Toast.makeText(this, "you examine the area", Toast.LENGTH_SHORT).show();
                iv.setImageResource(images[roomstate]);
                break;


            default:
                throw new IllegalStateException("Unexpected value: " + v.getId());
        }
}}