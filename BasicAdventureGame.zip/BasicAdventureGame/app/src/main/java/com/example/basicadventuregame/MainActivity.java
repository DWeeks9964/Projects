package com.example.basicadventuregame;
//imports
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Random;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
//varibles
public int gold;
public int health = 10;
public int keys = 0;
    ArrayList<String> inventory = new ArrayList<String>();
int images[]={R.drawable.room1,R.drawable.room2,R.drawable.room3, R.drawable.room4};
public int roomstate = 0;
    Random random = new Random();

    int randomNumber = random.nextInt(8 - 6) + 6;
    int i1=randomNumber;

    boolean flag;
ImageView iv;





//creating buttons and listeners
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageButton button1 = findViewById(R.id.up);
        ImageButton button2 = findViewById(R.id.down);
        ImageButton button3 = findViewById(R.id.left);
        ImageButton button4 = findViewById(R.id.right);
        Button button5 = findViewById(R.id.examine);
        Button cmd1 = findViewById(R.id.command1);
        Button cmd2 = findViewById(R.id.command2);
        Button cmd3 = findViewById(R.id.command3);
        Button cmd4 = findViewById(R.id.command4);
        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        button4.setOnClickListener(this);
        button5.setOnClickListener(this);
        cmd1.setOnClickListener(this);
        cmd2.setOnClickListener(this);
        cmd3.setOnClickListener(this);
        cmd4.setOnClickListener(this);








  iv=(ImageView) findViewById(R.id.baseImage);


        flag = true;

        //b1.setOnClickListener(new View.OnClickListener() {
          //  @Override
            //public void onClick(View v) {
              //  iv.setImageResource(images[roomstate]);}
                //public void upclick(View view){
                  //  roomstate = 1;
                //}








    }

//switch statements. Most of the rooms are here
    @Override

    public void onClick(View v) {
        TextView info = (TextView)findViewById(R.id.areaInfo);



        switch (v.getId()) {
            case R.id.command1:
                if ((roomstate == 1) || (keys == 3)) {
                    info.setText("You win!!");}

                else if (roomstate == 0) {
                    gold = +10;
                }
                else if (roomstate == 2) {
                    health = -i1;
                }
                else if (roomstate == 3) {
                    keys = +1;
                }
                break;
            case R.id.command2:
                if (roomstate == 0 ) {
                    info.setText("Something bites the rope. You pull up a fish with a gem tied to it..");
                    keys = +1;
                }
                else if (roomstate == 2) {
                    keys =+ 1;
                    info.setText("you found a gem");
//commands for 3
            }
            break;
            case R.id.command3:
                if (roomstate == 1) {
                    inventory.add("rope");
                    info.setText("You retrieve a rope hanging from the ceiling");
                }
                else if (roomstate == 2) {
                    gold = +1;

            }

                break;
            case R.id.command4:
                if ((roomstate == 4) || gold < 10)  {
                info.setText("Not enough gold stranga");

                }
            else if ((roomstate == 4) || gold >= 10)  {
                gold = -10;
                keys = +1;
                info.setText("Thanks you kindly");

            }
            case R.id.up:

                if (roomstate == 0 ){
                roomstate = 1;}
                info.setText("You see an alter with slots for three gems. There are rooms to your left and right.");


                break;
            case R.id.down:
                if (roomstate == 1 ){
                roomstate = 0;
            info.setText("The room you started in. Check pouch with 1. Check hole with 2. Check ceiling with 3.");}

            break;
            case R.id.left:
                if (roomstate ==1){
                    roomstate =3;
                info.setText("You find a coffin in an empty room.");}
                else if (roomstate ==2){
                    roomstate =1;
                info.setText("You see an alter with slots for three gems. There are rooms to your left and right.");}
                break;
            case R.id.right:
                if (roomstate ==1){
                    roomstate =2;}
                Toast.makeText(this, "Button 4 clicked", Toast.LENGTH_SHORT).show();
                break;
            case R.id.examine:
                Toast.makeText(this, "you examine the area", Toast.LENGTH_SHORT).show();
                iv.setImageResource(images[roomstate]);
                break;


    }
}}